function mudaCEP() {
    $("#content").load("./pages/busca-cep.html");
    $(".sidenav-overlay").click();
}
function mudaCalc() {
    $("#content").load("pages/calculadora.html");
    $(".sidenav-overlay").click();
}
function mudaAluno() {
    $("#content").load("pages/nota-aluno.html");
    $(".sidenav-overlay").click();
}
function mudaPessoa() {
    $("#content").load("pages/pessoas.html");
    $(".sidenav-overlay").click();
}