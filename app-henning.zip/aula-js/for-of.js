const alunos = ["ana", "deividson", "audrey"]
let i = 1
for (let aluno of alunos) {
    console.log(`aluno ${i}`, aluno)
    i++
}