var valor = 12
valor = valor % 5 // igual a
var valor2 = valor / 3 // igual a

var pessoa1 = true
var pessoa2 = false
var pessoa3 = false

console.log('o resultado é ', (pessoa1 ^ pessoa2 ^ pessoa3)) // ou exclusivo XOR = V
// se uma conseguir a nota 10 eu contrato
var valor3 = 4

valor3++ // incremento
valor3-- // decremento

console.log('valor: ', valor);
console.log('valor2: ', valor2);
console.log('valor4: ', valor3);