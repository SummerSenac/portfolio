    const notas =  [10,5,6,7]
    console.log('tamanho', notas.length)

    const alunos = ["ana", "deividson", "audrey"]

    for (let index = 0; index < 10; index++) {
        console.log(index, alunos[index])  
    }
    
    for (let i = 0; i < notas.length; i++) {
        console.log('indice', i, 'valor: ',notas[i] )     
    }