var valor = 31
var valor1 = 20
var valor2 = 50

function maiorQueTrinta(num1, num2) {
    let valorNew = num1 + num2
    if (valorNew > 30) {
        return "é maior que 30"
    } else {
        return "é menor que 30"
    }
}

 // chamando a função
console.log('soma é: ', maiorQueTrinta(10,60));
console.log('passei nesse aqui')
console.log('passei nesse outro aqui')
console.log('passei nesse outro aqui de novo')